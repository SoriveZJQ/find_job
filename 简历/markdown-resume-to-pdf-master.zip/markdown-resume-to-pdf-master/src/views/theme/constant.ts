export const templateCategory = [
  '全部',
  '运营',
  '商务',
  '互联网',
  '简约',
  '暗黑',
  '社招',
  '通用',
  '研究生复试'
]
