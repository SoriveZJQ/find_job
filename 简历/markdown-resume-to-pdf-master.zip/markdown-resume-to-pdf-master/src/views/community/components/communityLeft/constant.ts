export const tabs = ['推荐', '最新', '我的']
