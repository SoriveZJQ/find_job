<template>
  <div id="not_found">404 抱歉～您要找的页面没有找到</div>
</template>
