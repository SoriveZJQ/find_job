<script setup lang="ts">
// import { io } from "socket.io-client";

// const socket = io("ws://localhost:3001");

// socket.on('chat message', (msg) => {
//   console.log("客户端接收到消息",msg)
// })

// socket.on("connect", () => {
//   console.log('链接了')
// })
</script>

<template>
  <span>聊天室</span>
</template>

<style lang="scss" scoped></style>
