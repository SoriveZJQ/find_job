export interface IMenuBarItem {
  level: number
  title: string
  offset: number
  offsetMax: number
  target: HTMLElement
}
