export enum Tip {
  NETWORK_ERROR = '网络发生了一点小故障，请检查网络问题再来试试吧～',
  BE_INCOMPLATE = '请输入完整的账户信息',
  VERIFY_CODE_INVAILED = '验证码错误，请重新尝试'
}
